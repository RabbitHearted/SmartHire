import './App.css';
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import LandingPage from './pages/LandingPage';
import Navbar from './components/Navbar';
import RegisterForm from './components/RegisterForm';
import LoginForm from './components/LoginForm';
import AdminLoginForm from './components/AdminLoginForm';
import JobBoard from './pages/jobseeker/Jobboard';
import HRAdminDashboard from './pages/hr/Dashboard';

import ProtectedRoute from './middleware/ProtectedRoute'; 

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/register" element={<RegisterForm />} />
        <Route path="/login" element={<LoginForm />} />
        <Route path="/hr-login" element={<AdminLoginForm />} />

        {/* Protected Route for Job Seekers */}
        <Route element={<ProtectedRoute allowedRoles={['jobseeker']} />}>
          <Route path="/jobboard" element={<JobBoard />} />
        </Route>

        {/* Protected Route for HR admin */}
        <Route element={<ProtectedRoute allowedRoles={['hr']} />}>
          <Route path="/admin/dashboard" element={<HRAdminDashboard />} />
        </Route>

      </Routes>
    </Router>
  );
}

export default App;
