import { useState } from "react";
import Footer from "../../components/Footer";

function JobBoard() {
  const [filters] = useState({
    employmentType: ["Full Time Jobs"],
    experienceLevel: ["Mid Level", "Senior Level"],
    salaryMin: 10000,
    salaryMax: 50000,
  });

  return (
    <div>
      <div className="max-w-screen-xl mx-auto px-6 py-4 flex items-center justify-between">
        {/* Search Bar */}
        <div className="flex-1 max-w-2xl mx-auto">
          <div className="relative flex">
            <input
              type="text"
              placeholder="Search for jobs..."
              className="w-full border border-blue-500 rounded-l-full px-4 py-2 outline-none"
            />
            <button className="bg-blue-600 text-base text-white px-6 flex items-center justify-center rounded-r-full hover:bg-blue-700">
              <p className="whitespace-nowrap">Find Job</p>
            </button>
          </div>
        </div>
      </div>

      <div className="flex px-6 py-2 bg-gray-50 max-w-screen-xl mx-auto">
        {/* Sidebar Filters */}
        <aside className="w-1/4 p-4 bg-white rounded-lg shadow">
          <div className="mb-6">
            <h3 className="font-semibold mb-2">Employment Type</h3>
            {[
              "Full Time Jobs",
              "Part Time Jobs",
              "Remote Jobs",
              "Internship Jobs",
              "Training Jobs",
            ].map((type) => (
              <div key={type} className="flex items-center mb-1">
                <input
                  type="checkbox"
                  defaultChecked={filters.employmentType.includes(type)}
                  className="mr-2"
                />
                <label>{type}</label>
              </div>
            ))}
          </div>

          <div className="mb-6">
            <h3 className="font-semibold mb-2">Experience Level</h3>
            {[
              "Student Level",
              "Entry Level",
              "Mid Level",
              "Senior Level",
              "Directors",
              "VP or Above",
            ].map((level) => (
              <div key={level} className="flex items-center mb-1">
                <input
                  type="checkbox"
                  defaultChecked={filters.experienceLevel.includes(level)}
                  className="mr-2"
                />
                <label>{level}</label>
              </div>
            ))}
          </div>

          <div className="">
            <h3 className="font-semibold mb-2">Salary Range</h3>
            <div className="flex space-x-2 mb-2">
              <input
                type="number"
                className="w-1/2 p-1 border rounded"
                placeholder="Min"
                defaultValue={filters.salaryMin}
              />
              <input
                type="number"
                className="w-1/2 p-1 border rounded"
                placeholder="Max"
                defaultValue={filters.salaryMax}
              />
            </div>
            <div className="flex space-x-2">
              <button className="px-4 py-1 bg-blue-600 text-white rounded">
                Enter
              </button>
              <button className="px-4 py-1 bg-gray-200 text-gray-700 rounded">
                Reset
              </button>
            </div>
          </div>
        </aside>

        {/* Main Job Listings */}
        <main className="w-3/4 pl-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">100 Jobs Found</h2>
            <select className="border rounded px-2 py-1">
              <option>Newest Post</option>
              <option>Oldest Post</option>
            </select>
          </div>

          <div className="grid grid-cols-3 gap-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-lg shadow p-4">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-lg font-bold">
                    {["Ps", "Xd", "Ai", "Ae", "X", "3"][i]}
                  </div>
                  <div className="ml-3">
                    <h3 className="font-semibold">Job Title {i + 1}</h3>
                    <span className="text-blue-500 text-sm">Department</span>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-4">
                  Php {10000 + i * 100}, Full-Time, 8-hour shift
                </p>
                <p className="text-sm text-gray-500 mb-4">
                  It is a long established fact that a reader will be
                  distracted...
                </p>
                <div className="flex flex-wrap gap-2 text-xs text-white">
                  <span className="bg-gray-600 px-2 py-1 rounded">Design</span>
                  <span className="bg-gray-600 px-2 py-1 rounded">
                    User Experience
                  </span>
                  <span className="bg-gray-600 px-2 py-1 rounded">Senior</span>
                </div>
                <p className="text-xs text-gray-400 mt-4">28 March 2025</p>
              </div>
            ))}
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
}

export default JobBoard;
