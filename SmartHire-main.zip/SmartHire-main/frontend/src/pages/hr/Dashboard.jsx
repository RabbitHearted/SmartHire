import React from "react";
import { Briefcase, Users, BarChart, PlusCircle } from "lucide-react";

const HRAdminDashboard = () => {
  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <header className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Welcome, HR Admin</h1>
        <p className="text-sm text-gray-600">
          Manage job posts, applicants, and more
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Card: Post New Job */}
        <div className="bg-white shadow rounded-2xl p-6 hover:shadow-md transition">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-800">Post a Job</h2>
            <PlusCircle className="w-6 h-6 text-indigo-500" />
          </div>
          <p className="text-sm text-gray-600 mt-2">Create a new job listing</p>
          <button className="mt-4 bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition">
            Create Job
          </button>
        </div>

        {/* Card: Manage Applicants */}
        <div className="bg-white shadow rounded-2xl p-6 hover:shadow-md transition">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-800">Applicants</h2>
            <Users className="w-6 h-6 text-teal-500" />
          </div>
          <p className="text-sm text-gray-600 mt-2">
            Review and shortlist candidates
          </p>
          <button className="mt-4 bg-teal-600 text-white px-4 py-2 rounded-md hover:bg-teal-700 transition">
            View Applicants
          </button>
        </div>

        {/* Card: Analytics */}
        <div className="bg-white shadow rounded-2xl p-6 hover:shadow-md transition">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-800">Analytics</h2>
            <BarChart className="w-6 h-6 text-pink-500" />
          </div>
          <p className="text-sm text-gray-600 mt-2">
            Track job performance & hires
          </p>
          <button className="mt-4 bg-pink-600 text-white px-4 py-2 rounded-md hover:bg-pink-700 transition">
            View Analytics
          </button>
        </div>
      </div>
    </div>
  );
};

export default HRAdminDashboard;
