import React from 'react';
import { Link } from 'react-router-dom';
import Footer from '../components/Footer';

const LandingPage = () => {
  return (
    <div>
<div className="min-h-screen bg-white text-gray-800 max-w-screen-xl mx-auto px-4 py-12">
      {/* Hero Section */}
      <header className="text-center">
        <h1 className="text-2xl sm:text-4xl font-bold leading-tight mb-4">
          CONNECTING <span className="text-text-highlight">JOB APPLICANTS</span> AND <span className="text-text-highlight">HR DEPARTMENT</span><br />
          TO JOBS THAT MATTER
        </h1>
        <p className="text-base sm:text-lg text-text-light mb-6 max-w-5xl mx-auto font-semibold">
          Explore opportunities tailored to your goals, connect with employers who recognize your talent, and take the next big step in your professional journey.
        </p>
        <Link
          to="#"
          className="bg-text-highlight text-white px-6 py-2 rounded-md font-medium hover:opacity-90 transition"
        >
          Start Your Job Search
        </Link>
      </header>

      {/* Subheading */}
      <section className="mt-16 text-center">
        <h2 className="text-xl sm:text-2xl text-text-semilight font-extrabold ">
          With SMARTHIRE, finding a job inside the UST-L Campus is easier than ever
        </h2>
      </section>

      {/* CTA Cards */}
      <section className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-4xl mx-auto">
        <div className="bg-text-highlight text-white p-6 rounded-md shadow-md">
          <h3 className="text-xl font-bold mb-2">Unlock your potential</h3>
          <p className="text-sm mb-4">Get hired now!</p>
          <Link
            to="#"
            className="bg-white text-text-highlight font-semibold text-sm px-4 py-2 rounded-md"
          >
            Register Now
          </Link>
        </div>
        <div className="bg-white border p-6 rounded-md shadow-md">
          <h3 className="text-xl font-bold mb-2">Find your next star</h3>
          <p className="text-sm mb-4">Connect with top talent now!</p>
          <Link
            to="#"
            className="bg-text-highlight text-white font-semibold text-sm px-4 py-2 rounded-md"
          >
            Post a Job
          </Link>
        </div>
      </section>

      {/* Featured Section */}
      <section className="mt-16 text-center">
        <h2 className="text-xl sm:text-2xl font-extrabold">FEATURED JOBS</h2>
        <div className="mt-6 flex flex-col sm:flex-row justify-center gap-6">
          {/* Job Card 1 */}
          <div className="bg-white p-4 border rounded-md shadow-sm w-full sm:w-1/2">
            <div className="flex items-center space-x-2 font-bold text-sm mb-1">
              <img src="/photoshop-icon.png" alt="Photoshop" className="w-6 h-6" />
              <span>Senior Product Designer – Growth</span>
            </div>
            <p className="text-xs text-text-highlight mb-2">Department</p>
            <p className="text-sm">Php 10,520 per Month</p>
            <div className="flex flex-wrap gap-2 mt-3 text-xs">
              <span className="bg-text-highlight text-white px-2 py-1 rounded-md">Mid-Senior</span>
              <span className="bg-text-highlight text-white px-2 py-1 rounded-md">Full-Time</span>
              <span className="bg-text-highlight text-white px-2 py-1 rounded-md">8-hour shift</span>
            </div>
            <p className="text-xs mt-2 text-right font-medium">Hiring Now!</p>
          </div>

          {/* Job Card 2 */}
          <div className="bg-white p-4 border rounded-md shadow-sm w-full sm:w-1/2">
            <div className="flex items-center space-x-2 font-bold text-sm mb-1">
              <img src="/xd-icon.png" alt="XD" className="w-6 h-6" />
              <span>Market Research Analyst</span>
            </div>
            <p className="text-xs text-text-highlight mb-2">Department</p>
            <p className="text-sm">Php 10,000 per Month</p>
            <div className="flex flex-wrap gap-2 mt-3 text-xs">
              <span className="bg-text-highlight text-white px-2 py-1 rounded-md">Mid-Senior</span>
              <span className="bg-text-highlight text-white px-2 py-1 rounded-md">Full-Time</span>
              <span className="bg-text-highlight text-white px-2 py-1 rounded-md">8-hour shift</span>
            </div>
            <p className="text-xs mt-2 text-right font-medium">Hiring Now!</p>
          </div>
        </div>
        <button className="mt-6 border px-4 py-2 rounded-md text-sm hover:bg-gray-100 transition">Browse More</button>
      </section>

      {/* CTA Section */}
      <section className="mt-16 text-center">
        <h2 className="text-xl sm:text-2xl font-extrabold mb-2">Your Next Great Job is Just a Click Away</h2>
        <p className="text-text-light font-medium mb-6">Be a member of UST-Legazpi and start your journey toward a better career.</p>
        <Link to="#" className="bg-text-highlight text-white px-6 py-2 rounded-md font-medium hover:opacity-90 transition">Get Started</Link>
      </section>

      
    </div>
    <div className="bg-footer-bg">
      <Footer />
    </div>
    </div>
    
  );
};

export default LandingPage;
