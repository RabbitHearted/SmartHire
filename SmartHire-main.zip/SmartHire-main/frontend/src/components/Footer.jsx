import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-footer-bg text-gray-800 px-4 py-10 mt-20">
      <div className="max-w-screen-xl mx-auto grid grid-cols-1 sm:grid-cols-4 gap-8 text-sm">
        {/* Logo + Copyright */}
        <div className="space-y-2 sm:col-span-1">
          <div className="flex items-center space-x-2 font-bold text-lg">
            <span>SMARTHIRE</span>
            <img src="/logo.svg" alt="SmartHire Logo" className="h-5 w-5" />
          </div>
          <p className="text-gray-600">&copy; {new Date().getFullYear()} SMARTHIRE. All rights reserved.</p>
        </div>

        {/* Footer Links */}
        <div>
          <h4 className="font-semibold mb-2">APPLICANTS</h4>
          <ul className="space-y-1">
            <li><Link to="#" className="hover:text-text-highlight">Job Search</Link></li>
            <li><Link to="#" className="hover:text-text-highlight">Profile</Link></li>
            <li><Link to="#" className="hover:text-text-highlight">Saved Jobs</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-2">HR DEPARTMENT</h4>
          <ul className="space-y-1">
            <li><Link to="#" className="hover:text-text-highlight">Register</Link></li>
            <li><Link to="#" className="hover:text-text-highlight">Post Job Ad</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-2">ABOUT SMARTHIRE</h4>
          <ul className="space-y-1">
            <li><Link to="#" className="hover:text-text-highlight">Terms of Service</Link></li>
            <li><Link to="#" className="hover:text-text-highlight">Privacy Policy</Link></li>
            <li><Link to="#" className="hover:text-text-highlight">Cookies</Link></li>
          </ul>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
