// import { useState } from 'react';
// import API from '../api';

// function RegisterForm() {
//   const [username, setUsername] = useState('');
//   const [password, setPassword] = useState('');

//   const handleRegister = async (e) => {
//     e.preventDefault();
//     try {
//       await API.post('register/', { username, password });
//       alert('User registered successfully!');
//     } catch (err) {
//       alert('Registration failed.');
//       console.error(err);
//     }
//   };

//   return (
//     <form onSubmit={handleRegister}>
//       <h2>Register</h2>
//       <input type="text" placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} />
//       <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} />
//       <button type="submit">Register</button>
//     </form>
//   );
// }

// export default RegisterForm;
import { useState } from "react";
import API from "../api";
import Footer from "../components/Footer";

function RegisterForm() {
  const [form, setForm] = useState({
    first_name: "",
    last_name: "",
    email: "",
    password: "",
    confirm_password: "",
    role: "jobseeker",
  });

  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setSuccess(false);
    try {
      await API.post("register/", form);
      setSuccess(true);
      setLoading(false);

      setForm({
        first_name: "",
        last_name: "",
        email: "",
        password: "",
        confirm_password: "",
        role: "jobseeker",
      });
    } catch (err) {
      alert("Registration failed");
      console.error(err.response?.data || err);
      setLoading(false);
    }
  };
  return (
    <div className="mt-16">
      <form
        onSubmit={handleSubmit}
        className="bg-gradient-to-b from-blue-500 to-blue-800 p-8 rounded-lg w-full max-w-lg mx-auto text-white"
      >
        <h2 className="text-center text-xl font-bold mb-6">
          Create a Job Applicant Account
        </h2>

        <div className="space-y-4">
          <div className="form-group">
            <input
              id="first_name"
              name="first_name"
              type="text"
              placeholder="First Name"
              value={form.first_name}
              onChange={handleChange}
              className="input w-full p-3 mt-2 rounded-lg text-gray-800 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="form-group">
            <input
              id="last_name"
              name="last_name"
              type="text"
              placeholder="Last Name"
              value={form.last_name}
              onChange={handleChange}
              className="input w-full p-3 mt-2 rounded-lg text-gray-800 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="form-group">
            <input
              id="email"
              name="email"
              type="email"
              placeholder="Email"
              value={form.email}
              onChange={handleChange}
              className="input w-full p-3 mt-2 rounded-lg text-gray-800 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="form-group">
            <input
              id="password"
              name="password"
              type="password"
              placeholder="Password"
              value={form.password}
              onChange={handleChange}
              className="input w-full p-3 mt-2 rounded-lg text-gray-800 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="form-group">
            <input
              id="confirm_password"
              name="confirm_password"
              type="password"
              placeholder="Confirm Password"
              value={form.confirm_password}
              onChange={handleChange}
              className="input w-full p-3 mt-2 rounded-lg text-gray-800 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="bg-white text-blue-700 font-bold py-2 mt-6 rounded w-full hover:bg-blue-700 hover:text-white transition duration-300"
        >
          {loading ? "Registering..." : "Register"}
        </button>

        {success && (
          <div className="mt-6 bg-green-600 bg-opacity-20 border border-green-400 text-green-100 rounded p-4 text-center transition-all duration-300">
            <h3 className="text-lg font-semibold mb-2">
              Registration Successful 🎉
            </h3>
            <p className="mb-2">
              Your account has been successfully created. You’re just one step
              away from exploring exciting job opportunities tailored to your
              profile.
            </p>
            <p>
              <a
                href="/login"
                className="underline text-green-200 hover:text-white font-semibold"
              >
                Click here to log in
              </a>{" "}
              and start your journey with SmartHire.
            </p>
          </div>
        )}

        <div className="flex items-center my-6">
          <hr className="flex-grow border-white" />
          <span className="mx-2">OR</span>
          <hr className="flex-grow border-white" />
        </div>

        <button
          type="button"
          className="bg-white text-black font-semibold py-2 w-full rounded flex items-center justify-center"
        >
          <svg
            width="24px"
            height="24px"
            viewBox="0 0 32 32"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
            <g
              id="SVGRepo_tracerCarrier"
              stroke-linecap="round"
              stroke-linejoin="round"
            ></g>
            <g id="SVGRepo_iconCarrier">
              {" "}
              <path
                d="M30.0014 16.3109C30.0014 15.1598 29.9061 14.3198 29.6998 13.4487H16.2871V18.6442H24.1601C24.0014 19.9354 23.1442 21.8798 21.2394 23.1864L21.2127 23.3604L25.4536 26.58L25.7474 26.6087C28.4458 24.1665 30.0014 20.5731 30.0014 16.3109Z"
                fill="#4285F4"
              ></path>{" "}
              <path
                d="M16.2863 29.9998C20.1434 29.9998 23.3814 28.7553 25.7466 26.6086L21.2386 23.1863C20.0323 24.0108 18.4132 24.5863 16.2863 24.5863C12.5086 24.5863 9.30225 22.1441 8.15929 18.7686L7.99176 18.7825L3.58208 22.127L3.52441 22.2841C5.87359 26.8574 10.699 29.9998 16.2863 29.9998Z"
                fill="#34A853"
              ></path>{" "}
              <path
                d="M8.15964 18.769C7.85806 17.8979 7.68352 16.9645 7.68352 16.0001C7.68352 15.0356 7.85806 14.1023 8.14377 13.2312L8.13578 13.0456L3.67083 9.64746L3.52475 9.71556C2.55654 11.6134 2.00098 13.7445 2.00098 16.0001C2.00098 18.2556 2.55654 20.3867 3.52475 22.2845L8.15964 18.769Z"
                fill="#FBBC05"
              ></path>{" "}
              <path
                d="M16.2864 7.4133C18.9689 7.4133 20.7784 8.54885 21.8102 9.4978L25.8419 5.64C23.3658 3.38445 20.1435 2 16.2864 2C10.699 2 5.8736 5.1422 3.52441 9.71549L8.14345 13.2311C9.30229 9.85555 12.5086 7.4133 16.2864 7.4133Z"
                fill="#EB4335"
              ></path>{" "}
            </g>
          </svg>{" "}
          &nbsp; Continue with Google
        </button>

        <p className="text-center mt-4 text-white">
          Already a User?{" "}
          <a href="/login" className="underline text-white">
            Login Now
          </a>
        </p>
      </form>

      <Footer />
    </div>
  );
}

export default RegisterForm;
