import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../api';
import Footer from '../components/Footer';

function LoginForm() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: '' }); // clear error on change
  };

  const handleSubmit = async (e) => {
  e.preventDefault();
  setErrors({});
  setLoading(true); // start loading

  try {
    const res = await API.post('token/', form);
    localStorage.setItem('access', res.data.access);
    localStorage.setItem('refresh', res.data.refresh);
    if (res.data.user) {
      localStorage.setItem('user', JSON.stringify(res.data.user));
    }

    navigate('/');
    window.location.reload();
  } catch (err) {
    if (err.response && err.response.status === 401) {
      setErrors({ password: 'Invalid email or password.' });
    } else {
      setErrors({ password: 'Something went wrong. Please try again.' });
    }
  } finally {
    setLoading(false); // end loading
  }
};


  return (
    <div className='mt-16'>
      <form
        onSubmit={handleSubmit}
        className="bg-gradient-to-b from-blue-500 to-blue-900 p-8 rounded-lg w-full max-w-lg mx-auto text-white"
      >
        <h2 className="text-center text-xl font-bold">WELCOME BACK!</h2>
        <h2 className="text-center text-base font-normal mb-6">Enter your details</h2>

        <div className="space-y-4">
          <div className="form-group">
            <input
              id="email"
              name="email"
              type="email"
              placeholder="Email"
              value={form.email}
              onChange={handleChange}
              className="input w-full p-3 mt-2 rounded-lg text-gray-800 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {errors.email && <p className="text-red-200 text-sm mt-1">{errors.email}</p>}
          </div>

          <div className="form-group">
            <input
              id="password"
              name="password"
              type="password"
              placeholder="Password"
              value={form.password}
              onChange={handleChange}
              className="input w-full p-3 mt-2 rounded-lg text-gray-800 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {errors.password && <p className="text-red-200 text-sm mt-1">{errors.password}</p>}
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className={`bg-white text-blue-700 font-bold py-2 mt-6 rounded w-full transition duration-300
            ${loading ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-700 hover:text-white'}
          `}
          >
            {loading ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin h-5 w-5 mr-2 text-blue-700" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
              </svg>
              Logging in...
            </span>
          ) : (
            'Login'
          )}

        </button>



        <div className="flex items-center my-6">
          <hr className="flex-grow border-white" />
          <span className="mx-2">OR</span>
          <hr className="flex-grow border-white" />
        </div>

        <button type="button" className="bg-white text-black font-semibold py-2 w-full rounded flex items-center justify-center">
          {/* Google Icon */}
         <svg width="24px" height="24px" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M30.0014 16.3109C30.0014 15.1598 29.9061 14.3198 29.6998 13.4487H16.2871V18.6442H24.1601C24.0014 19.9354 23.1442 21.8798 21.2394 23.1864L21.2127 23.3604L25.4536 26.58L25.7474 26.6087C28.4458 24.1665 30.0014 20.5731 30.0014 16.3109Z" fill="#4285F4"></path> <path d="M16.2863 29.9998C20.1434 29.9998 23.3814 28.7553 25.7466 26.6086L21.2386 23.1863C20.0323 24.0108 18.4132 24.5863 16.2863 24.5863C12.5086 24.5863 9.30225 22.1441 8.15929 18.7686L7.99176 18.7825L3.58208 22.127L3.52441 22.2841C5.87359 26.8574 10.699 29.9998 16.2863 29.9998Z" fill="#34A853"></path> <path d="M8.15964 18.769C7.85806 17.8979 7.68352 16.9645 7.68352 16.0001C7.68352 15.0356 7.85806 14.1023 8.14377 13.2312L8.13578 13.0456L3.67083 9.64746L3.52475 9.71556C2.55654 11.6134 2.00098 13.7445 2.00098 16.0001C2.00098 18.2556 2.55654 20.3867 3.52475 22.2845L8.15964 18.769Z" fill="#FBBC05"></path> <path d="M16.2864 7.4133C18.9689 7.4133 20.7784 8.54885 21.8102 9.4978L25.8419 5.64C23.3658 3.38445 20.1435 2 16.2864 2C10.699 2 5.8736 5.1422 3.52441 9.71549L8.14345 13.2311C9.30229 9.85555 12.5086 7.4133 16.2864 7.4133Z" fill="#EB4335"></path> </g></svg>
          &nbsp; Continue with Google
        </button>

        <p className="text-center mt-4 text-white">
          Don't have an account? <a href="/register" className="underline text-white">Register Now</a>
        </p>
      </form>

      <Footer />
    </div>
  );
}

export default LoginForm;
