import { useState } from "react";
import API from "../api";
import Footer from "../components/Footer";
import { useNavigate } from "react-router-dom";

function AdminLoginForm() {
  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post("token/", form);

      const decodedToken = JSON.parse(atob(res.data.access.split(".")[1]));
      const role = decodedToken.role;

      if (role !== "hr") {
        setError("Access denied. You are not an HR user.");
        return;
      }

      localStorage.setItem("access", res.data.access);
      localStorage.setItem("refresh", res.data.refresh);
      navigate("/admin/dashboard");
      window.location.reload();
    } catch (err) {
      console.error(err);
      setError("Login failed");
    }
  };

  return (
    <div className="mt-16">
      <form
        onSubmit={handleSubmit}
        className="bg-gradient-to-b from-purple-500 to-purple-900 p-8 rounded-lg w-full max-w-lg mx-auto text-white"
      >
        <h2 className="text-center text-xl font-bold">ADMIN LOGIN</h2>
        <h2 className="text-center text-base font-normal mb-6">
          HR access only
        </h2>

        {error && <p className="text-red-300 text-center mb-4">{error}</p>}

        <div className="space-y-4">
          <div className="form-group">
            <input
              id="email"
              name="email"
              type="email"
              placeholder="Email"
              value={form.email}
              onChange={handleChange}
              className="input w-full p-3 mt-2 rounded-lg text-gray-800 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-500"
              required
            />
          </div>

          <div className="form-group">
            <input
              id="password"
              name="password"
              type="password"
              placeholder="Password"
              value={form.password}
              onChange={handleChange}
              className="input w-full p-3 mt-2 rounded-lg text-gray-800 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-500"
              required
            />
          </div>
        </div>

        <button
          type="submit"
          className="bg-white text-purple-700 font-bold py-2 mt-6 rounded w-full hover:bg-purple-700 hover:text-white transition duration-300"
        >
          Login
        </button>

        <p className="text-center mt-4 text-white">
          Not an admin?{" "}
          <a href="/login" className="underline text-white">
            Login as Jobseeker
          </a>
        </p>
      </form>

      <Footer />
    </div>
  );
}

export default AdminLoginForm;
