import React, { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Menu, X, ChevronDown } from "lucide-react";
import { AuthContext } from "../context/AuthContext";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const { user, setUser } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("access");
    localStorage.removeItem("refresh");
    localStorage.removeItem("user");
    setUser(null);
    navigate("/login");
  };

  return (
    <div className="bg-gray-100">
      <nav className="max-w-screen-xl bg-gray-100 mx-auto px-6 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-10">
          <Link to="/" className="flex items-center space-x-2">
            <span className="text-lg font-extrabold">SMARTHIRE</span>
            <img src="/logo.svg" alt="SmartHire Logo" className="h-6 w-6" />
          </Link>

          <ul className="hidden md:flex space-x-8 text-sm font-medium text-gray-800">
            <li>
              <Link to="/jobboard" className="hover:text-text-highlight">
                Find Jobs
              </Link>
            </li>
            <li>
              <Link to="#" className="hover:text-text-highlight">
                FAQs
              </Link>
            </li>
          </ul>
        </div>

        <div className="hidden md:flex items-center space-x-6 text-sm font-medium">
          {user ? (
            <div className="relative">
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="flex items-center space-x-1 text-gray-800 hover:text-text-highlight"
              >
                <span>{user.first_name}</span>
                <ChevronDown className="w-4 h-4" />
              </button>
              {dropdownOpen && (
                <div className="absolute right-0 mt-2 w-40 bg-white shadow-lg rounded-md z-50">
                  <Link
                    to="/profile"
                    className="block px-4 py-2 text-sm hover:bg-gray-100"
                  >
                    Profile
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="block w-full text-left px-4 py-2 text-sm hover:bg-gray-100"
                  >
                    Logout
                  </button>
                </div>
              )}
            </div>
          ) : (
            <>
              <Link
                to="/hr-login"
                className="block text-text-highlight hover:underline"
              >
                HR Department
              </Link>
              <Link
                to="/login"
                className="text-gray-800 hover:text-text-highlight"
              >
                Log In
              </Link>
              <Link
                to="/register"
                className="bg-text-highlight text-white px-4 py-2 rounded-md hover:opacity-90 transition"
              >
                Register
              </Link>
            </>
          )}
        </div>

        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden text-gray-800 focus:outline-none"
        >
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </nav>

      {/* Mobile Dropdown */}
      {isOpen && (
        <div className="md:hidden px-6 pb-4 space-y-3 text-sm font-medium text-gray-800">
          <Link to="/jobboard" className="block hover:text-text-highlight">
            Find Jobs
          </Link>
          <Link to="#" className="block hover:text-text-highlight">
            FAQs
          </Link>
          <Link
            to="/hr-login"
            className="block text-text-highlight hover:underline"
          >
            HR Department
          </Link>

          {user ? (
            <>
              <Link to="/profile" className="block hover:text-text-highlight">
                Profile
              </Link>
              <button
                onClick={handleLogout}
                className="block text-left w-full hover:text-text-highlight"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="block hover:text-text-highlight">
                Log In
              </Link>
              <Link
                to="/register"
                className="block bg-text-highlight text-white px-4 py-2 rounded-md hover:opacity-90 transition w-fit"
              >
                Register
              </Link>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default Navbar;
